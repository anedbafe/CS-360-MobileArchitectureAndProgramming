package com.zybooks.inventoryapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.zybooks.inventoryapp.database.DBHelper;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    BottomNavigationView bottomNavigation;
    ListView productListView;
    EditText searchProduct;
    TextView smsAlerts;
    DBHelper dbHelper;
    ArrayList<String> productList;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Verify for SMS permit granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECEIVE_SMS}, 1);
        }

        // Linking xml elements
        productListView = findViewById(R.id.productListView);
        searchProduct = findViewById(R.id.searchProduct);
        smsAlerts = findViewById(R.id.smsAlerts);
        bottomNavigation = findViewById(R.id.bottomNavigation);
        dbHelper = new DBHelper(this);
        productList = new ArrayList<>();

        // load products when program init
        loadProducts("");

        // filter the products in realtime
        searchProduct.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                loadProducts(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });

        // bottom menu bar icon settings when clicked
        bottomNavigation.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                return true;
            } else if (id == R.id.nav_modify) {
                startActivity(new Intent(MainActivity.this, ModifyActivity.class));
                return true;
            } else if (id == R.id.nav_settings) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                return true;
            }
            return false;
        });

        // load SMS low stock alert and display in the main or home screen
        loadSmsAlerts();
    }

    // method to filter product by name
    private void loadProducts(String filter) {
        productList.clear();
        Cursor cursor = dbHelper.readProducts();

        if (cursor.moveToFirst()) {
            do {
                String name = cursor.getString(1);
                String quantity = cursor.getString(2);
                String location = cursor.getString(3);

                // product display information
                String productInfo = name + " - Qty: " + quantity + " - Loc: " + location;

                // when user type in the filter text this will look up for product
                if (filter.isEmpty() || name.toLowerCase().contains(filter.toLowerCase())) {
                    productList.add(productInfo);
                }

                // check stock availability and send alert
                int qty = Integer.parseInt(quantity);
                if (qty <= 1) {
                    updateSmsAlerts("Low stock: " + name + " (" + qty + " available)");
                }

            } while (cursor.moveToNext());
        }
        cursor.close();

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, productList);
        productListView.setAdapter(adapter);
    }

    // this method will hold all the alerts and will update as product stock is low
    @SuppressLint("SetTextI18n")
    private void updateSmsAlerts(String message) {
        String currentText = smsAlerts.getText().toString();
        if (currentText.equals("No item with minimum stock availability")) {
            smsAlerts.setText(message);
        } else {
            smsAlerts.setText(currentText + "\n" + message);
        }
        smsAlerts.setVisibility(TextView.VISIBLE);
    }

    // when app start load previous sms alerts
    @SuppressLint("SetTextI18n")
    private void loadSmsAlerts() {
        smsAlerts.setText("No item with minimum stock availability");
        smsAlerts.setVisibility(TextView.GONE);
    }

    @Override
    // when user is in a differ UI and returns to home product list will reload for any changes
    protected void onResume() {
        super.onResume();
        loadProducts("");
    }

    // check is sms was allow or denied by the user
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permit granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS denied authorization", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
