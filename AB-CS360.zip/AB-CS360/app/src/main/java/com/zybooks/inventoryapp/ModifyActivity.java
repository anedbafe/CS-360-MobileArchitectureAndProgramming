package com.zybooks.inventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.zybooks.inventoryapp.database.DBHelper;
import java.util.ArrayList;

public class ModifyActivity extends AppCompatActivity {

    EditText searchProduct, productName, productQuantity, productLocation;
    Button btnAddProduct, btnUpdateProduct, btnDeleteProduct, btnCleanForm;
    ListView productListView;
    DBHelper dbHelper;
    ArrayList<String> productList;
    ArrayAdapter<String> adapter;
    String selectedProductId = null;
    BottomNavigationView bottomNavigation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // link xml layout file elements
        searchProduct = findViewById(R.id.searchProduct);
        productName = findViewById(R.id.productName);
        productQuantity = findViewById(R.id.productQuantity);
        productLocation = findViewById(R.id.productLocation);
        btnAddProduct = findViewById(R.id.btnAddProduct);
        btnUpdateProduct = findViewById(R.id.btnUpdateProduct);
        btnDeleteProduct = findViewById(R.id.btnDeleteProduct);
        btnCleanForm = findViewById(R.id.btnCleanForm);
        productListView = findViewById(R.id.productListView);
        bottomNavigation = findViewById(R.id.bottomNavigation);
        dbHelper = new DBHelper(this);

        // load product list when app starts
        loadProducts("");

        // filter products in real time
        searchProduct.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                loadProducts(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });

        // clear btn form
        btnCleanForm.setOnClickListener(view -> clearFields());

        // bottom menu bar icon settings
        bottomNavigation.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                startActivity(new Intent(ModifyActivity.this, MainActivity.class));
                return true;
            } else if (id == R.id.nav_modify) {
                return true;
            } else if (id == R.id.nav_settings) {
                startActivity(new Intent(ModifyActivity.this, SettingsActivity.class));
                return true;
            }
            return false;
        });

        // add btn listener
        btnAddProduct.setOnClickListener(view -> {
            String name = productName.getText().toString().trim();
            String quantity = productQuantity.getText().toString().trim();
            String location = productLocation.getText().toString().trim();

            if (name.isEmpty() || quantity.isEmpty() || location.isEmpty()) {
                Toast.makeText(ModifyActivity.this, "Complete all fields.", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean insertSuccess = dbHelper.insertProduct(name, Integer.parseInt(quantity), location);
            if (insertSuccess) {
                Toast.makeText(ModifyActivity.this, "Product saved!", Toast.LENGTH_SHORT).show();
                clearFields();
                loadProducts("");
            } else {
                Toast.makeText(ModifyActivity.this, "Check product information!", Toast.LENGTH_SHORT).show();
            }
        });

        btnUpdateProduct.setOnClickListener(view -> {
            if (selectedProductId == null || selectedProductId.isEmpty()) {
                Toast.makeText(ModifyActivity.this, "Select a product!", Toast.LENGTH_SHORT).show();
                return;
            }

            String name = productName.getText().toString().trim();
            String quantityStr = productQuantity.getText().toString().trim();
            String location = productLocation.getText().toString().trim();

            if (name.isEmpty() || quantityStr.isEmpty() || location.isEmpty()) {
                Toast.makeText(ModifyActivity.this, "Complete all fields.", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                int productId = Integer.parseInt(selectedProductId);
                int quantity = Integer.parseInt(quantityStr);
                boolean updateSuccess = dbHelper.updateProduct(productId, name, quantity, location);

                if (updateSuccess) {
                    Toast.makeText(ModifyActivity.this, "Product modified!", Toast.LENGTH_SHORT).show();
                    clearFields();
                    loadProducts("");
                } else {
                    Toast.makeText(ModifyActivity.this, "Check product information!", Toast.LENGTH_SHORT).show();
                }

            } catch (NumberFormatException e) {
                Toast.makeText(ModifyActivity.this, "Error: Invalid data type!", Toast.LENGTH_SHORT).show();
            }
        });

        btnDeleteProduct.setOnClickListener(view -> {
            if (selectedProductId == null) {
                Toast.makeText(ModifyActivity.this, "Select a product!", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean deleteSuccess = dbHelper.deleteProduct(Integer.parseInt(selectedProductId));
            if (deleteSuccess) {
                Toast.makeText(ModifyActivity.this, "Product deleted!", Toast.LENGTH_SHORT).show();
                clearFields();
                loadProducts("");
            } else {
                Toast.makeText(ModifyActivity.this, "Check product information!", Toast.LENGTH_SHORT).show();
            }
        });

        // method to identify product selected on the list
        productListView.setOnItemClickListener((parent, view, position, id) -> {
            String selectedItem = productList.get(position);
            String[] parts = selectedItem.split(" - ");

            if (parts.length >= 4) {
                selectedProductId = parts[0].trim();
                productName.setText(parts[1].trim());  // prdN
                productQuantity.setText(parts[2].trim()); // prdQty
                productLocation.setText(parts[3].trim()); // prdLoc
            } else {
                Toast.makeText(ModifyActivity.this, "Error! Select a product.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // method to load product and filtering by name
    private void loadProducts(String filter) {
        productList = new ArrayList<>();
        Cursor cursor = dbHelper.readProducts();

        if (cursor.moveToFirst()) {
            do {
                String id = cursor.getString(0);
                String name = cursor.getString(1); // name
                String quantity = cursor.getString(2); // qty
                String location = cursor.getString(3); // loc

                // how info will be display
                String productInfo = id + " - " + name + " - " + quantity + " - " + location;

                // filter prod by name
                if (filter.isEmpty() || name.toLowerCase().contains(filter.toLowerCase())) {
                    productList.add(productInfo);
                }
            } while (cursor.moveToNext());
        }
        cursor.close();

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, productList);
        productListView.setAdapter(adapter);
    }

// btn clear all fields
    private void clearFields() {
        productName.setText("");
        productQuantity.setText("");
        productLocation.setText("");
        selectedProductId = null;
    }

    // on resume UI product list will be reload
    @Override
    protected void onResume() {
        super.onResume();
        loadProducts("");
    }

    @Override
    public boolean onOptionsItemSelected(android.view.MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
